# -*- coding: utf-8 -*-
"""
Created on Sat Aug 29 01:13:52 2020

@author: Deepak
"""


import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle
from joblib import load

app = Flask(__name__)
model = pickle.load(open('decison2.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/y_predict',methods=['POST'])
def y_predict():
    '''
    For rendering results on HTML GUI
    '''
    name=[x for x in request.form.values()]
    name1=name[0]
    name.pop(0)
    x_test = [[float(x) for x in name]]
    print(x_test)
    prediction = model.predict(x_test)
    print(prediction)
    output=prediction[0]
    if(output==0):
        pred=',you have high risk of having the Chronic Kidney Disease.'
    else:
        pred=",you have very little risk of having the Chronic Kidney Disease."
    return render_template('index.html', prediction_text='Dear '+name1+'{}'.format(pred))

if __name__ == "__main__":
    app.run(debug=True)